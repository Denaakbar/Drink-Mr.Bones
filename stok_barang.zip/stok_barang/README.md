# README #

Source Code Aplikasi Stok dan Penjualan Barang

By [Kang Jaz](https://kangjaz.com)
